import 'package:flutter/material.dart';
import 'package:flutter9_shop/auth/changePassword.dart';
import 'package:flutter9_shop/auth/editUser.dart';
import 'package:flutter9_shop/common/textStyle.dart';
import 'package:flutter9_shop/shop/cart.dart';
import 'package:flutter9_shop/shop/category.dart';
import 'package:flutter9_shop/shop/homeScreen.dart';
import 'package:flutter9_shop/shop/orders.dart';
import 'package:flutter9_shop/shop/products.dart';
import 'package:flutter9_shop/shop/whishlist.dart';
import 'package:get/get.dart';

dynamic customDrawer(int selectedPageValue){
  final pageList = [
    {"pageName": "Home", "icon": Icons.home , "value" : 1},
    {"pageName": "Category", "icon": Icons.category , "value" : 2} ,
    {"pageName": "Product", "icon": Icons.gif_box_rounded , "value" : 3},
    {"pageName": "Cart", "icon": Icons.shopping_cart , "value" : 4},
    {"pageName": "Wishlist", "icon": Icons.favorite , "value" : 5},
    {"pageName": "Orders", "icon": Icons.reorder , "value" : 6},
    {"pageName": "Edit user", "icon": Icons.verified_user , "value" : 7},
    {"pageName": "Change password", "icon": Icons.settings , "value" : 8},
  ];

  void handleNavigation(dynamic currentPage){
    print("Current page $currentPage");
    if(currentPage == 1){
      Get.to(()=>HomeScreen());
    }
    else if(currentPage == 2){
      Get.to(() => CategoryScreen());
    }
    else if(currentPage == 3){
      Get.to(() => ProductScreen());
    }
    else if(currentPage == 4){
      Get.to(() => CartScreen());
    }
    else if(currentPage == 5){
      Get.to(() => WishlistScreen());
    }
    else if(currentPage == 6){
      Get.to(() => OrdersScreen());
    }
    else if(currentPage == 7){
      Get.to(() => EditUserScreen());
    }
    else if(currentPage == 8){
      Get.to(() => ChangePasswordScreen());
    }
  }

  return Drawer(
    child: Column(
      children: [
        Container(
            child: Image.asset(
              "images/flutter_logo2.png",
              height: 100,
            )),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Container(
                height: 440,
                child: ListView.builder(itemBuilder: (context,index){
                  return InkWell(
                    onTap: (){
                      handleNavigation(pageList[index]['value']);
                    },
                    child: Container(
                      height: 50,
                      margin: EdgeInsets.only(bottom: 10),
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: selectedPageValue ==  pageList[index]['value'] ? Colors.orange : Colors.white,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          children: [
                            Icon(pageList[index]['icon'] as IconData?),
                            SizedBox(
                              width: 20,
                            ),
                            customText(pageList[index]['pageName'].toString()),
                          ],
                        ),
                      ),
                    ),
                  );
                }, itemCount: pageList.length,),
              )
            ],
          ),
        ),
      ],
    ),
  ) ;
}