import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../common/textStyle.dart';

class ForgotPassowordScreen extends StatefulWidget {
  @override
  _ForgotPassowordScreenState createState() => _ForgotPassowordScreenState();
}

class _ForgotPassowordScreenState extends State<ForgotPassowordScreen> {
  final _formKey = GlobalKey<FormState>();
  String _email = '';

  void _onEmailChange(String value) {
    setState(() {
      _email = value;
    });
  }

  void _onForgotPasswordClick() {
    if (_formKey.currentState!.validate()) {
      print('Change Password button pressed');
      // Add your change password logic here
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFF7F00),
      body: Padding(
        padding: const EdgeInsets.only(bottom: 16.0, left: 16.0, right: 16.0),
        child: Center(
          child: Container(
            height: MediaQuery.of(context).size.height * 0.40,
            width: MediaQuery.of(context).size.width * 0.70,
            padding: EdgeInsets.only(left: 15, right: 15, top: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Color.fromRGBO(0, 0, 0, 0.25),
                  offset: Offset(0, 14),
                  blurRadius: 28,
                ),
                BoxShadow(
                  color: Color.fromRGBO(0, 0, 0, 0.22),
                  offset: Offset(0, 10),
                  blurRadius: 10,
                ),
              ],
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  customText("Forgot Password", fontSize: 35, fontWeight: FontWeight.bold),
                  customText("Recover your password"),
                  SizedBox(height: 10),
                  Form(
                    key: _formKey,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8.0),
                          child: TextFormField(
                            onChanged: _onEmailChange,
                            obscureText: true,
                            decoration: InputDecoration(
                              hintText: 'Email address',
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                        SizedBox(height: 13.0),
                        ElevatedButton(
                          onPressed: _onForgotPasswordClick,
                          child: Text('Forgot Password'),
                          style: ElevatedButton.styleFrom(
                            primary: Color(0xFFFF7F00),
                            onPrimary: Colors.white,
                            minimumSize: Size(double.infinity, 48),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}