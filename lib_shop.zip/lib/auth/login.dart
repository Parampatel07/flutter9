import 'package:flutter/material.dart';
import 'package:flutter9_shop/auth/forgotPassword.dart';
import 'package:flutter9_shop/auth/register.dart';
import 'package:flutter9_shop/shop/homeScreen.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:get/get.dart';
import '../common/textStyle.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  String _email = '';
  String _password = '';

  void _onEmailChanged(String value) {
    setState(() {
      _email = value;
    });
    print('Email: $_email');
  }

  void _onPasswordChanged(String value) {
    setState(() {
      _password = value;
    });
    print('Password: $_password');
  }

  void _onLoginPressed() {
    // if (_formKey.currentState!.validate()) {
      print('Login button pressed');
      Get.to(() => HomeScreen());
    // }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFF7F00),
      body: Padding(
        padding: const EdgeInsets.only(bottom :16.0 , left:  16.0 , right: 16.0),
        child: Center(
          child: Container(
            height: MediaQuery.of(context).size.height * 0.60 ,
            width: MediaQuery.of(context).size.width * 0.60 ,
            padding: EdgeInsets.only(left: 15,right: 15 ,top: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Color.fromRGBO(0, 0, 0, 0.25), // rgba(0, 0, 0, 0.25)
                  offset: Offset(0, 14), // 0px 14px
                  blurRadius: 28, // 28px
                ),
                BoxShadow(
                  color: Color.fromRGBO(0, 0, 0, 0.22), // rgba(0, 0, 0, 0.22)
                  offset: Offset(0, 10), // 0px 10px
                  blurRadius: 10, // 10px
                ),
              ],
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [customText("Login " , fontSize: 45 , fontWeight: FontWeight.bold) ,
                  customText("Let's get started "),
                  SizedBox(height: 10),
                  Form(
                  key: _formKey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        child: TextFormField(
                          onChanged: _onEmailChanged,
                          decoration: InputDecoration(
                            hintText: 'Email',
                            border: OutlineInputBorder(),
                          ),
                          validator: (value) {
                            if (value!.isEmpty || !value!.contains('@')) {
                              return 'Please enter a valid email address';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(height: 14.0),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        child: TextFormField(
                          onChanged: _onPasswordChanged,
                          obscureText: true,
                          decoration: InputDecoration(
                            hintText: 'Password',
                            border: OutlineInputBorder(),
                          ),
                          validator: (value) {
                            if (value!.isEmpty || value!.length < 6) {
                              return 'Password must be at least 6 characters';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(height: 13.0),
                      ElevatedButton(
                        onPressed: _onLoginPressed,
                        child: Text('Login'),
                        style: ElevatedButton.styleFrom(
                          primary: Color(0xFFFF7F00),
                          onPrimary: Colors.white,
                          minimumSize: Size(double.infinity, 48),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          TextButton(
                            onPressed: () {
                              Get.to(() => ForgotPassowordScreen());
                              print('Forget password pressed');
                            },
                            child: Text('Forget password'),
                          ),
                          TextButton(
                            onPressed: () {
                              Get.to(() => RegisterScreen());
                              print('Register button pressed');
                            },
                            child: Text('Register now'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),]
              ),
            ),
          ),
        ),
      ),
    );
  }
}