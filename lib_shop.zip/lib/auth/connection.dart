import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiConnection {
  // Base URL for API endpoints
  static const String baseUrl = 'https://www.theeasylearnacademy.com/shop/ws/';

  // Headers that will be used in requests
  static final Map<String, String> headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  };

  // Generic POST request method
  static Future<dynamic> postRequest({
    required String endpoint,
    required Map<String, dynamic> data,
  }) async {
    try {
      final url = Uri.parse('$baseUrl$endpoint');
      print('Making POST request to: $url');
      print('Request data: $data');
      final response = await http.post(
        url,
        headers: headers,
        body: jsonEncode(data),
      );

      print('Response status code: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 200) {
        // Successful response
          return jsonDecode(response.body);
      } else {
        // Handle error responses
        throw ApiException(
          statusCode: response.statusCode,
          message: 'Request failed: ${response.body}',
        );
      }
    } catch (e) {
      throw ApiException(
        statusCode: 500,
        message: 'Error making request: $e',
      );
    }
  }

  // Example of how to add other HTTP methods
  // GET request method
  static Future<dynamic> getRequest({
    required String endpoint,
    Map<String, dynamic>? queryParams,
  }) async {
    try {
      final uri = Uri.parse('$baseUrl$endpoint').replace(
        queryParameters: queryParams,
      );

      final response = await http.get(uri, headers: headers);

      if (response.statusCode >= 200) {
        return jsonDecode(response.body);
      } else {
        throw ApiException(
          statusCode: response.statusCode,
          message: 'Request failed: ${response.body}',
        );
      }
    } catch (e) {
      throw ApiException(
        statusCode: 500,
        message: 'Error making request: $e',
      );
    }
  }
}

// Custom exception class for API errors
class ApiException implements Exception {
  final int statusCode;
  final String message;

  ApiException({
    required this.statusCode,
    required this.message,
  });

  @override
  String toString() => 'ApiException: $message (Status Code: $statusCode)';
}