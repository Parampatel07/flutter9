import 'package:flutter/material.dart';
import 'package:flutter9_shop/common/textStyle.dart';

class PrivacyPolicyScreen extends StatefulWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  State<PrivacyPolicyScreen> createState() => _PrivacyPolicyScreenState();
}

class _PrivacyPolicyScreenState extends State<PrivacyPolicyScreen> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: customText("Privacy policy goes here" , fontSize: 50 , fontWeight: FontWeight.bold),
    );
  }
}
