import 'package:flutter/material.dart';
import 'package:flutter9_shop/common/AppBar.dart';
import 'package:flutter9_shop/common/Drawer.dart';
import 'package:flutter9_shop/common/textStyle.dart';
import 'package:flutter9_shop/shop/cart.dart';
import 'package:flutter9_shop/shop/whishlist.dart';
import 'package:get/get.dart';

class SingleProduct extends StatefulWidget {
  const SingleProduct({super.key});

  @override
  State<SingleProduct> createState() => _SingleProductState();
}

class _SingleProductState extends State<SingleProduct> {
  int selectedPageValue = 99 ;
  final stockData = {
    "Stock": "7",
    "Weight": "0",
    "Size": "N/A", // Default "N/A" if empty
  };
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar(),
      drawer: customDrawer(selectedPageValue),
      body: SingleChildScrollView(
        child: Container(
          width: MediaQuery.of(context).size.width ,
          child: Column(
            children: [
              Image.network("https://i5.walmartimages.com/seo/HP-14-Laptop-Intel-Core-i3-1115G4-4GB-RAM-128G-SSD-Natural-Silver-Windows-11-Home-in-S-mode-14-dq2031wm_d3df6009-cc66-44f8-b45e-16b8cb670e8c.22c4512667d72a24e1a97ba67bd5fc0d.jpeg" , height: 200,) ,
              Container(
                alignment: Alignment.topLeft,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        customText("Product - 1" , fontSize: 30 , fontWeight: FontWeight.bold),
                        customText("Category - 1" , fontSize: 20),
                      ],
                    ),
                    customText("₹1200" , fontSize: 20),
                    customText("The Indian rupee (symbol: ₹; code: INR) is the official currency in the Republic of India. The rupee is subdivided into 100 paise (Hindi plural; singular: paisa). " , fontSize: 20),
                    SizedBox(
                      height: 20,
                    ),
                    SizedBox(
                      width: 200,
                      child: Table(
                        columnWidths: const {
                          0: IntrinsicColumnWidth(), // Adjust the width of the first column
                        },
                        border: TableBorder.all(
                          color: Colors.black26,
                          style: BorderStyle.solid,
                          width: 1,
                        ),
                        children: stockData.entries.map((entry) {
                          return TableRow(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  entry.key,
                                  style: const TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(entry.value),
                              ),
                            ],
                          );
                        }).toList(),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    ElevatedButton(
                      onPressed: (){
                        Get.to(() => CartScreen());
                      },
                      child: Text('Add to Cart'),
                      style: ElevatedButton.styleFrom(
                        primary: Color(0xFFFF7F00),
                        onPrimary: Colors.white,
                        minimumSize: Size(double.infinity, 48),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    ElevatedButton(
                      onPressed: (){
                        Get.to(() => WishlistScreen());
                      },
                      child: Text('Add to wishlist'),
                      style: ElevatedButton.styleFrom(
                        primary: Colors.white ,
                        onPrimary: Colors.black,
                        minimumSize: Size(double.infinity, 48),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ) ,
          margin: EdgeInsets.all(20),
        ),
      ),
    );
  }
}
