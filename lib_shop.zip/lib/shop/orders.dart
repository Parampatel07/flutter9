import 'package:flutter/material.dart';
import 'package:flutter9_shop/common/AppBar.dart';
import 'package:flutter9_shop/common/Drawer.dart';
import 'package:flutter9_shop/common/textStyle.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  int selectedPageValue = 6;
  int CartQuantity = 10;
  int CartAmount = 1200 ;
  String shipped = "Shipped";
  String inProgress = "In progress";
  dynamic handlePlusButtonClick() {
    setState(() {
      CartQuantity = CartQuantity + 1;
    });
  }

  dynamic handleMinusButtonClick() {
    if (CartQuantity >= 1) {
      setState(() {
        CartQuantity = CartQuantity - 1;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar(),
      drawer: customDrawer(selectedPageValue),
      body: Container(
        alignment: Alignment.topLeft,
        margin: EdgeInsets.all(20),
        height: MediaQuery.of(context).size.height * 0.90,
        width: MediaQuery.of(context).size.width,
        // color: Colors.red,
        child: ListView.builder(itemBuilder: (context,index){
          return Container(
            margin: EdgeInsets.all(7),
            padding: EdgeInsets.all(10),
            height: 120,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: Colors.orange,
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  child: Column(
                    children: [
                      SizedBox(
                        width: 400,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                customText("Full name"),
                                customText("Date : 31/01/2025"),
                                Row(
                                  children: [
                                    InkWell(
                                      onTap: () {
                                        handleMinusButtonClick();
                                      },
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: index % 2 == 0 ? Color(0xff184D47) : Color(0xffA20A0A),
                                          borderRadius:
                                          BorderRadius.circular(10),
                                        ),
                                        padding: EdgeInsets.symmetric( vertical: 7,
                                            horizontal: 15),
                                        child: Text(index % 2 == 0 ? shipped : inProgress ,style: TextStyle(
                                          color: Colors.white,
                                        ),),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            customText("₹1200"),
                          ],
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
          );
        },
          itemCount: 5,
        )
        ,),
    );
  }
}
