import 'package:flutter/material.dart';
import 'package:flutter9_shop/common/AppBar.dart';
import 'package:flutter9_shop/common/Drawer.dart';
import 'package:flutter9_shop/common/textStyle.dart';

class SingleOrder extends StatefulWidget {
  const SingleOrder({super.key});

  @override
  State<SingleOrder> createState() => _SingleOrderState();
}

class _SingleOrderState extends State<SingleOrder> {
  int selectedPageValue = 99 ;
  final stockData = {
    "Bill date ": "31/01/2025",
    "Address 1 ": "hill drive",
    "Address 2 ": "opp akshar wadi temple",
    "City ": "Bhavnagar",
    "Pincode ": "364001",
  };
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar(),
      drawer: customDrawer(selectedPageValue),
      body: SingleChildScrollView(
        child: Container(
          width: MediaQuery.of(context).size.width ,
          child: Column(
            children: [
              Container(
                alignment: Alignment.topLeft,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        customText("Full name" , fontSize: 30 , fontWeight: FontWeight.bold),
                        Container(
                          decoration: BoxDecoration(
                            color:  Color(0xffA20A0A),
                            borderRadius:
                            BorderRadius.circular(10),
                          ),
                          padding: EdgeInsets.symmetric( vertical: 7,
                              horizontal: 15),
                          child: Text("In progress" ,style: TextStyle(
                            color: Colors.white,
                          ),),
                        ),
                      ],
                    ),
                    customText("₹1200" , fontSize: 20),
                    SizedBox(
                      height: 20,
                    ),
                    SizedBox(
                      child: Table(
                        columnWidths: const {
                          0: IntrinsicColumnWidth(), // Adjust the width of the first column
                        },
                        border: TableBorder.all(
                          color: Colors.black26,
                          style: BorderStyle.solid,
                          width: 1,
                        ),
                        children: stockData.entries.map((entry) {
                          return TableRow(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  entry.key,
                                  style: const TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(entry.value),
                              ),
                            ],
                          );
                        }).toList(),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ) ,
          margin: EdgeInsets.all(20),
        ),
      ),
    );
  }
}
