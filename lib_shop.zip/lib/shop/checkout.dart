import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../common/textStyle.dart';

class CheckOutScreen extends StatefulWidget {
  @override
  _CheckOutScreenState createState() => _CheckOutScreenState();
}

class _CheckOutScreenState extends State<CheckOutScreen> {
  final _formKey = GlobalKey<FormState>();
  String _username = '';
  String _email = '';
  String _password = '';
  String _mobileNumber = '';
  String? selectedCity;
  List<String> cities = ["Bhavnagar", "Ahmedabad", "Surat", "Rajkot", "Vadodara"];

  void _onUsernameChanged(String value) {
    setState(() {
      _username = value;
    });
    print('Username: $_username');
  }

  void _onEmailChanged(String value) {
    setState(() {
      _email = value;
    });
    print('Email: $_email');
  }

  void _onPasswordChanged(String value) {
    setState(() {
      _password = value;
    });
    print('Password: $_password');
  }

  void _onMobileNumberChanged(String value) {
    setState(() {
      _mobileNumber = value;
    });
    print('Mobile Number: $_mobileNumber');
  }

  void _onRegisterPressed() {
    if (_formKey.currentState!.validate()) {
      print('Register button pressed');
      print('Username: $_username');
      print('Email: $_email');
      print('Mobile Number: $_mobileNumber');
      // Add your registration logic here
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFF7F00),
      body: Padding(
        padding: const EdgeInsets.only(bottom: 16.0, left: 16.0, right: 16.0),
        child: Center(
          child: Container(
            height: MediaQuery.of(context).size.height * 0.90,
            width: MediaQuery.of(context).size.width * 0.70,
            padding: EdgeInsets.only(left: 15, right: 15, top: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Color.fromRGBO(0, 0, 0, 0.25),
                  offset: Offset(0, 14),
                  blurRadius: 28,
                ),
                BoxShadow(
                  color: Color.fromRGBO(0, 0, 0, 0.22),
                  offset: Offset(0, 10),
                  blurRadius: 10,
                ),
              ],
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  customText("Checkout", fontSize: 45, fontWeight: FontWeight.bold),
                  customText("Order now"),
                  SizedBox(height: 10),
                  Form(
                    key: _formKey,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8.0),
                          child: TextFormField(
                            onChanged: _onUsernameChanged,
                            decoration: InputDecoration(
                              hintText: 'Full name',
                              border: OutlineInputBorder(),
                            ),
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'Please enter your fullname';
                              }
                              if (value.length < 3) {
                                return 'full name  must be at least 7 characters';
                              }
                              return null;
                            },
                          ),
                        ),
                        SizedBox(height: 14.0),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8.0),
                          child: Container(
                            padding: EdgeInsets.symmetric(vertical: 4 , horizontal: 10),
                            width: double.infinity,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              border: Border.all(color: Colors.grey) ,
                            ),
                            child: DropdownButton<String>(
                                underline: SizedBox() ,
                              hint: Text("Select a city"),
                              value: selectedCity,
                              onChanged: (String? newValue) {
                                setState(() {
                                  selectedCity = newValue;
                                });
                              },
                              items: cities.map<DropdownMenuItem<String>>((String city) {
                                return DropdownMenuItem<String>(
                                  value: city,
                                  child: Text(city),
                                );
                              }).toList(),
                            ),
                          ),
                        ),
                        SizedBox(height: 14.0),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8.0),
                          child: TextFormField(
                            onChanged: _onPasswordChanged,
                            decoration: InputDecoration(
                              hintText: 'Pincode',
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                        SizedBox(height: 14.0),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8.0),
                          child: TextFormField(
                            onChanged: _onMobileNumberChanged,
                            keyboardType: TextInputType.number,
                            readOnly: true,
                            decoration: InputDecoration(
                              hintText: 'Amount',
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                        SizedBox(height: 14.0,),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8.0),
                          child: TextFormField(
                            minLines: 2,
                            maxLines: 2,
                            onChanged: _onUsernameChanged,
                            decoration: InputDecoration(
                              hintText: 'Address 1',
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                        SizedBox(height: 13.0),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8.0),
                          child: TextFormField(
                            minLines: 2,
                            maxLines: 2,
                            onChanged: _onUsernameChanged,
                            decoration: InputDecoration(
                              hintText: 'Address 2',
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                        SizedBox(height: 13.0),
                        ElevatedButton(
                          onPressed: _onRegisterPressed,
                          child: Text('Make payment '),
                          style: ElevatedButton.styleFrom(
                            primary: Color(0xFFFF7F00),
                            onPrimary: Colors.white,
                            minimumSize: Size(double.infinity, 48),
                          ),
                        ),
                        SizedBox(height: 13,)
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}