import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:notify/auth/change_password.dart';
import 'package:notify/auth/edit_user.dart';
import '../auth/login.dart';
import '../auth/policy.dart';
import 'colors.dart';
import 'customText.dart';

PreferredSizeWidget customeAppBar(centerText, linkText,
    {leadingIcon = Icons.arrow_back_ios,
    leadingIconSize = 12.01,
    screen = ""}) {
  return AppBar(
    centerTitle: true,
    title: customText(centerText, Colors.black, 16.01),
    leadingWidth: 85.01,
    leading: InkWell(
      onTap: () {
        if (screen == "view_notes") {
          Get.to(
                () => EditUser(),
            transition: Transition.leftToRight,
            duration: Duration(milliseconds: 2000),
          );
        } else {
          Get.back();
        }
      },
      child: Row(
        children: [
          SizedBox(
            width: 20.01,
          ),
          Icon(
            leadingIcon,
            color: Color(violetBlue),
            size: leadingIconSize,
          ),
          customText(linkText, Color(violetBlue), 16.01),
        ],
      ),
    ),
    actions: [
      PopupMenuButton(
        itemBuilder: (context) {
          return [
            if (screen != 'forgot_password')
              PopupMenuItem(
                child: InkWell(
                  onTap: () {
                    Get.to(
                          () => ChangePassword(),
                      transition: Transition.leftToRight,
                      duration: Duration(milliseconds: 2000),
                    );
                  },
                  child: Text("Change password"),
                ),
              ),
            PopupMenuItem(
              child: InkWell(
                onTap: () {
                  Get.to(
                        () => PrivacyPolicy(),
                    transition: Transition.leftToRight,
                    duration: Duration(milliseconds: 2000),
                  );
                },
                child: Text("Privacy policy"),
              ),
            ),
          ];
        },
      )
    ],
  );
}
