import 'package:flutter/material.dart';

import 'colors.dart';
import 'customText.dart';

PreferredSizeWidget customeAppBar(centerText, linkText,
    {leadingIcon = Icons.arrow_back_ios , leadingIconSize = 12}) {
  return AppBar(
    centerTitle: true,
    title: customText(centerText, Colors.black, 16),
    leadingWidth: 85,
    leading: Row(
      children: [
        SizedBox(
          width: 20,
        ),
        Icon(
          leadingIcon,
          color: Color(violetBlue),
          size: leadingIconSize,
        ),
        customText(linkText, Color(violetBlue), 16),
      ],
    ),
  );
}


