import 'package:flutter/material.dart';
import 'package:flutter9_shop/common/textStyle.dart';

dynamic customAppBar(){
  return AppBar(
    actions: [
      PopupMenuButton(
        itemBuilder: (BuildContext context) {
          return {'Privacy policy', 'Logout'}.map((String choice) {
            return PopupMenuItem<String>(
              value: choice,
              child: Text(choice),
            );
          }).toList();
        },
      ),
    ],
    toolbarHeight: 60,
    elevation: 10,
    title: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Image.asset(
          "images/appBarLogo.png",
          height: 50,
        ),
        SizedBox(
          width: 10,
        ),
        customText("Flutter 9 shop",
            fontSize: 30, fontWeight: FontWeight.bold)
      ],
    ),
  );
}