import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
dynamic customText(String message , {Color color = Colors.black , double fontSize = 20 , FontWeight fontWeight = FontWeight.normal}){
  return Text(message , style: GoogleFonts.titilliumWeb(
    textStyle: TextStyle(
      color: color ,
      fontSize: fontSize ,
      fontWeight: fontWeight ,
    ),
  ),);
}