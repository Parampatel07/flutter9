final dynamic violetBlue = 0xFF592F8D ;

final dynamic violetCard = 0xFF6A3EA1 ;
final dynamic yellowCard = 0xFFF8C715 ;
final dynamic redCard = 0xFFCE3A54 ;
final dynamic greenCard = 0xFF1F7F40 ;