import 'package:flutter/material.dart';

import 'colors.dart';
import 'customText.dart';

Widget DashboardCard(heading , subHeading , color , image){
  return Container(
    height: 180 ,
    width: 178,
    decoration: BoxDecoration(
      color: color,
      borderRadius: BorderRadius.circular(8),
    ),
    padding: EdgeInsets.all(16),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Image.asset(image , height: 56, width: 56,),
        SizedBox(height: 14,),
        customText(heading, Colors.white, 16 ,customFontWeight: FontWeight.bold),
        customText(subHeading, Colors.white, 12)
      ],
    ),
  );
}