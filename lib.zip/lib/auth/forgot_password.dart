import 'package:flutter/material.dart';
import 'package:notify/common/customeAppbar.dart';

import '../common/colors.dart';
import '../common/customText.dart';

class ForgotPassword extends StatefulWidget {
  const ForgotPassword({super.key});

  @override
  State<ForgotPassword> createState() => _ForgotPasswordState();
}

class _ForgotPasswordState extends State<ForgotPassword> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customeAppBar("Forget password", "Back"),
      body: Container(
        height: MediaQuery.of(context).size.height * 0.70,
        width: MediaQuery.of(context).size.width,
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: EdgeInsets.only(top: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      customText("Email address", Colors.black, 16 , customFontWeight: FontWeight.bold),
                      TextField(
                        keyboardType: TextInputType.emailAddress,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          // label: customText("Email", Colors.black, 16),
                          hintText: 'Example : abc@gmail.com',
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                    margin: EdgeInsets.only(top : 10),
                    child: customText("Back to login", Color(violetBlue), 16  ,customDecoration : TextDecoration.underline)),
                Container(
                  alignment: Alignment.center,
                  margin: EdgeInsets.only(top : 30),
                  child: MaterialButton(
                    child: customText("Reset password" , Colors.white , 16 , customFontWeight: FontWeight.w500) ,
                    onPressed: (){
                    },
                    color: Color(violetBlue) ,
                    height: 54,
                    minWidth: 343,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );;
  }
}
