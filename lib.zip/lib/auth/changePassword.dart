import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../common/textStyle.dart';

class ChangePasswordScreen extends StatefulWidget {
  @override
  _ChangePasswordScreenState createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  final _formKey = GlobalKey<FormState>();
  String _oldPassword = '';
  String _newPassword = '';
  String _confirmPassword = '';

  void _onOldPasswordChanged(String value) {
    setState(() {
      _oldPassword = value;
    });
  }

  void _onNewPasswordChanged(String value) {
    setState(() {
      _newPassword = value;
    });
  }

  void _onConfirmPasswordChanged(String value) {
    setState(() {
      _confirmPassword = value;
    });
  }

  void _onChangePasswordPressed() {
    if (_formKey.currentState!.validate()) {
      print('Change Password button pressed');
      // Add your change password logic here
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFF7F00),
      body: Padding(
        padding: const EdgeInsets.only(bottom: 16.0, left: 16.0, right: 16.0),
        child: Center(
          child: Container(
            height: MediaQuery.of(context).size.height * 0.65,
            width: MediaQuery.of(context).size.width * 0.70,
            padding: EdgeInsets.only(left: 15, right: 15, top: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Color.fromRGBO(0, 0, 0, 0.25),
                  offset: Offset(0, 14),
                  blurRadius: 28,
                ),
                BoxShadow(
                  color: Color.fromRGBO(0, 0, 0, 0.22),
                  offset: Offset(0, 10),
                  blurRadius: 10,
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                customText("Change Password", fontSize: 35, fontWeight: FontWeight.bold),
                customText("Update your password"),
                SizedBox(height: 10),
                Form(
                  key: _formKey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        child: TextFormField(
                          onChanged: _onOldPasswordChanged,
                          obscureText: true,
                          decoration: InputDecoration(
                            hintText: 'Old Password',
                            border: OutlineInputBorder(),
                          ),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please enter your old password';
                            }
                            if (value.length < 6) {
                              return 'Password must be at least 6 characters';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(height: 14.0),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        child: TextFormField(
                          onChanged: _onNewPasswordChanged,
                          obscureText: true,
                          decoration: InputDecoration(
                            hintText: 'New Password',
                            border: OutlineInputBorder(),
                          ),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please enter a new password';
                            }
                            if (value.length < 6) {
                              return 'New password must be at least 6 characters';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(height: 14.0),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        child: TextFormField(
                          onChanged: _onConfirmPasswordChanged,
                          obscureText: true,
                          decoration: InputDecoration(
                            hintText: 'Confirm New Password',
                            border: OutlineInputBorder(),
                          ),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please confirm your new password';
                            }
                            if (value != _newPassword) {
                              return 'Passwords do not match';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(height: 13.0),
                      ElevatedButton(
                        onPressed: _onChangePasswordPressed,
                        child: Text('Change Password'),
                        style: ElevatedButton.styleFrom(
                          primary: Color(0xFFFF7F00),
                          onPrimary: Colors.white,
                          minimumSize: Size(double.infinity, 48),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}