import 'package:flutter/material.dart';
import 'package:notify/common/customeAppbar.dart';

import '../common/colors.dart';
import '../common/customText.dart';

class EditUser extends StatefulWidget {
  const EditUser({super.key});

  @override
  State<EditUser> createState() => _EditUserState();
}

class _EditUserState extends State<EditUser> {

  final fullNameController = TextEditingController();
  final emailController = TextEditingController();

  @override
  void initState() {
    fullNameController.addListener(()=> {
      handleFullNameChnage()
    });
    emailController.addListener(() => {
      handleEmailChange()
    });
    super.initState();
  }

  void dispose(){
    fullNameController.dispose();
    emailController.dispose();
    super.dispose();
  }

  dynamic handleFullNameChnage(){
    print("Full name : " + fullNameController.text.toString());
  }

  dynamic handleEmailChange(){
    print("Email : " + emailController.text.toString());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customeAppBar("Edit user", "Back"),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(20),
          child :Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.only(top: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    customText("Full name", Colors.black, 16 ,customFontWeight: FontWeight.bold),
                    TextField(
                      controller: fullNameController,
                      keyboardType: TextInputType.text,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        // label: customText("Email", Colors.black, 16),
                        hintText: 'Example: jhon doe',
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    customText("Email Address", Colors.black, 16 ,customFontWeight: FontWeight.bold),
                    TextField(
                      controller: emailController,
                      keyboardType: TextInputType.emailAddress,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        // label: customText("Email", Colors.black, 16),
                        hintText: 'Example: abc@gmail.com',
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                alignment: Alignment.center,
                margin: EdgeInsets.only(top : 30),
                child: MaterialButton(
                  child: customText("Save changes" , Colors.white , 16 , customFontWeight: FontWeight.w500) ,
                  onPressed: (){
                  },
                  color: Color(violetBlue) ,
                  height: 54,
                  minWidth: 343,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
