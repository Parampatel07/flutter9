import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get_storage/get_storage.dart';
import 'package:notify/auth/forgot_password.dart';
import 'package:notify/auth/register.dart';
import 'package:notify/common/colors.dart';
import 'package:notify/common/customText.dart';
import 'package:get/get.dart';
import 'package:notify/notes/view_note.dart';
import 'package:notify/database/helper.dart';
import 'package:sqflite/sqflite.dart';

import '../database/userDatabaseHelper.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  dynamic passwordVisible = true;
  @override
  void initState() {
    super.initState();
    // TODO: implement initState
    emailController.addListener(() => {
      handleEmailChange()
    });
    passwordController.addListener(() => {
      handlePasswordChange()
    });
    // createDatabase();
  }



  void dispose(){
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  dynamic handleEmailChange(){
    print("Email : " + emailController.text.toString());
  }

  dynamic handlePasswordChange(){
    print("Password : " + passwordController.text.toString());
  }

  dynamic handlePasswordVisibleChange(){
    print(passwordVisible);
    setState(() {
      passwordVisible = !passwordVisible;
    });
    print("icon  click ");
  }

  dynamic handleLoginButtonClicked() async {
    String email = emailController.text.toString().trim();
    String password = passwordController.text.toString().trim();
    dynamic checkLogin = await checkUserLogin(email,password);
    if(checkLogin == true){
      Get.to(() => ViewNote(),transition: Transition.leftToRight ,duration : Duration(milliseconds: 2000));
    }
    else
      {
        Fluttertoast.showToast(
            msg: "Invalid Login Attempt ",
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.BOTTOM,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0,
            timeInSecForIosWeb: 5,
            webBgColor:
            "linear-gradient(342deg, rgba(196,12,12,1) 52%, rgba(196,12,12,1) 100%)",
            webPosition: "center");
      }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        margin: EdgeInsets.only(top : MediaQuery.of(context).size.height * 0.10),
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                customText("Let's Login", Colors.black, 32, customFontWeight: FontWeight.bold ),
                customText("and note your ideas", Colors.black, 16),
                Container(
                  margin: EdgeInsets.only(top: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      customText("Email Address", Colors.black, 16 ,customFontWeight: FontWeight.bold),
                      TextField(
                        controller: emailController,
                        keyboardType: TextInputType.emailAddress,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          // label: customText("Email", Colors.black, 16),
                          hintText: 'Example: abc@gmail.com',
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      customText("Password", Colors.black, 16 , customFontWeight: FontWeight.bold),
                      TextField(
                        controller: passwordController,
                        keyboardType: TextInputType.visiblePassword,
                          obscureText : passwordVisible,
                        decoration: InputDecoration(
                          suffixIcon : InkWell(
                            onTap: (){
                              handlePasswordVisibleChange();
                            },
                              child: passwordVisible == true ? Icon(Icons.remove_red_eye_outlined) : Icon(Icons.remove_red_eye_rounded) ) ,
                          border: OutlineInputBorder(),
                          // label: customText("Email", Colors.black, 16),
                          hintText: '********',
                        ),
                      )
                    ],
                  ),
                ),
                InkWell(
                  onTap: ()=>{
                  Get.to(() => ForgotPassword(),transition: Transition.leftToRight ,duration : Duration(milliseconds: 2000),)
                  },
                  child: Container(
                    margin: EdgeInsets.only(top : 10),
                      child: customText("Forgot Password", Color(violetBlue), 16  ,customDecoration : TextDecoration.underline)),
                ),
                Container(
                  alignment: Alignment.center,
                  margin: EdgeInsets.only(top : 30),
                  child: MaterialButton(
                    child: customText("Login" , Colors.white , 16 , customFontWeight: FontWeight.w500) ,
                    onPressed: (){
                      handleLoginButtonClicked() ;
                    },
                    color: Color(violetBlue) ,
                    height: 54,
                    minWidth: 343,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)),
                  ),
                ),
              ],
            ),
            InkWell(
              onTap: (){
                Get.to(() => Register(),transition: Transition.leftToRight ,duration : Duration(milliseconds: 2000),);
              },
              child: Container(
                  child: customText("Don't have an account ? Register here", Color(violetBlue), 16)),
            ),
          ],
        ),
      ),
    );
  }

}
