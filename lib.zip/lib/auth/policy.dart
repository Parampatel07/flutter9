// import 'package:flutter/material.dart';
// import 'package:flutter_inappwebview/flutter_inappwebview.dart';
//
// InAppWebViewController? webViewController;
//
// class Policy extends StatelessWidget {
//   const Policy({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       home: Scaffold(
//         body: Container(
//           child:InAppWebView(
//             initialUrlRequest: URLRequest(url: WebUri.uri(Uri.parse("https://parampatel07.github.io/flutter9/privacy_policy.html"))),
//             onWebViewCreated: (controller) {
//               webViewController = controller;
//             },
//             onLoadStart: (controller, url) {
//               print("Loading: $url");
//             },
//             onLoadStop: (controller, url) async {
//               print("Finished loading: $url");
//             },
//           ),
//         ),
//       ),
//     );;
//   }
// }
import 'package:flutter/material.dart';
import 'package:notify/common/customeAppbar.dart';

class PrivacyPolicy extends StatelessWidget {
  const PrivacyPolicy({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customeAppBar("Privacy policy ", "Back"),
      body: Center(
        child: Container(
          child: Text("Privacy policy goes here "),
        ),
      ),
    );
  }
}
