import 'package:flutter/material.dart';
import 'package:notify/auth/login.dart';
import 'package:notify/common/colors.dart';
import 'package:notify/common/customText.dart';
import 'package:get/get.dart';
import 'package:notify/database/userDatabaseHelper.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../database/sqflite_helper.dart';

class Register extends StatefulWidget {
  const Register({super.key});

  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  final fullNameController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final confirmPasswordController = TextEditingController();
  dynamic passwordVisible = true;
  dynamic confirmPasswordVisible = true;

  @override
  void initState() {
    fullNameController.addListener(() => {handleFullNameChnage()});
    emailController.addListener(() => {handleEmailChange()});
    passwordController.addListener(() => {handlePasswordChange()});
    confirmPasswordController
        .addListener(() => {handleConfirmPasswordChange()});
    super.initState();
  }

  void dispose() {
    fullNameController.dispose();
    emailController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();
    super.dispose();
  }

  dynamic handleFullNameChnage() {
    print("Full name : " + fullNameController.text.toString());
  }

  dynamic handleEmailChange() {
    print("Email : " + emailController.text.toString());
  }

  dynamic handlePasswordChange() {
    print("Password : " + passwordController.text.toString());
  }

  dynamic handleConfirmPasswordChange() {
    print("Confirm password : " + confirmPasswordController.text.toString());
  }

  dynamic handlePasswordVisibleChange() {
    setState(() {
      passwordVisible = !passwordVisible;
    });
  }

  dynamic handleConfirmPasswordVisibleChange() {
    setState(() {
      confirmPasswordVisible = !confirmPasswordVisible;
    });
  }

  Future<void> handleRegisterButtonClick() async {
    String name = fullNameController.text.toString();
    String email = emailController.text.toString();
    String password = passwordController.text.toString();
    String reTypePassword = confirmPasswordController.text.toString();
    name = name.trim();
    email = email.trim();
    password = password.trim();
    reTypePassword = reTypePassword.trim();
    if (password == reTypePassword &&
        name != "" &&
        email != "" &&
        password != "") {
      dynamic checkUser = await checkUserExits(email);
      print("this is checkUser ${checkUser}");
      if (checkUser == false) {
        Fluttertoast.showToast(
            msg: "Email is already taken ",
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.BOTTOM,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0,
            timeInSecForIosWeb: 5,
            webBgColor:
                "linear-gradient(342deg, rgba(196,12,12,1) 52%, rgba(196,12,12,1) 100%)",
            webPosition: "center");
      } else {
        String query =
            "insert into user (name , email , password ) values ( '${name}' , '${email}' , '${password}' )";
        insertValueUser(query);
        Get.to(
          () => Login(),
          transition: Transition.leftToRight,
          duration: Duration(milliseconds: 2000),
        );
      }
    } else {
      if (password != reTypePassword) {
        Fluttertoast.showToast(
            msg: "Password and retype password must be same ",
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.BOTTOM,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0,
            timeInSecForIosWeb: 5,
            webBgColor:
                "linear-gradient(342deg, rgba(196,12,12,1) 52%, rgba(196,12,12,1) 100%)",
            webPosition: "center");
      } else {
        Fluttertoast.showToast(
            msg: "Please fill all the inputs ",
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.BOTTOM,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0,
            timeInSecForIosWeb: 5,
            webBgColor:
                "linear-gradient(342deg, rgba(196,12,12,1) 52%, rgba(196,12,12,1) 100%)",
            webPosition: "center");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            InkWell(
                onTap: () {
                  Get.to(
                    () => Login(),
                    transition: Transition.leftToRight,
                    duration: Duration(milliseconds: 2000),
                  );
                },
                child: Icon(
                  Icons.arrow_back_ios,
                  color: Color(violetBlue),
                  size: 18,
                )),
            customText("Back to login", Color(violetBlue), 16),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              customText("Register", Colors.black, 32,
                  customFontWeight: FontWeight.bold),
              customText("and start taking notes", Colors.black, 16),
              Container(
                margin: EdgeInsets.only(top: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    customText("Full name", Colors.black, 16,
                        customFontWeight: FontWeight.bold),
                    TextField(
                      controller: fullNameController,
                      keyboardType: TextInputType.text,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        // label: customText("Email", Colors.black, 16),
                        hintText: 'Example: jhon doe',
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    customText("Email Address", Colors.black, 16,
                        customFontWeight: FontWeight.bold),
                    TextField(
                      controller: emailController,
                      keyboardType: TextInputType.emailAddress,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        // label: customText("Email", Colors.black, 16),
                        hintText: 'Example: abc@gmail.com',
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    customText("Password", Colors.black, 16,
                        customFontWeight: FontWeight.bold),
                    TextField(
                      controller: passwordController,
                      keyboardType: TextInputType.visiblePassword,
                      obscureText: passwordVisible,
                      decoration: InputDecoration(
                        suffixIcon: InkWell(
                          onTap: () {
                            handlePasswordVisibleChange();
                          },
                          child: passwordVisible == true
                              ? Icon(Icons.remove_red_eye_rounded)
                              : Icon(Icons.remove_red_eye_outlined),
                        ),
                        border: OutlineInputBorder(),
                        // label: customText("Email", Colors.black, 16),
                        hintText: '********',
                      ),
                    )
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    customText("Re-type password", Colors.black, 16,
                        customFontWeight: FontWeight.bold),
                    TextField(
                      controller: confirmPasswordController,
                      obscureText: confirmPasswordVisible,
                      keyboardType: TextInputType.visiblePassword,
                      decoration: InputDecoration(
                        suffixIcon: InkWell(
                          onTap: () {
                            handleConfirmPasswordVisibleChange();
                          },
                          child: confirmPasswordVisible == true
                              ? Icon(Icons.remove_red_eye_rounded)
                              : Icon(Icons.remove_red_eye_outlined),
                        ),
                        border: OutlineInputBorder(),
                        // label: customText("Email", Colors.black, 16),
                        hintText: '********',
                      ),
                    )
                  ],
                ),
              ),
              Container(
                alignment: Alignment.center,
                margin: EdgeInsets.only(top: 30),
                child: MaterialButton(
                  child: customText("Register", Colors.white, 16,
                      customFontWeight: FontWeight.w500),
                  onPressed: () {
                    handleRegisterButtonClick();
                  },
                  color: Color(violetBlue),
                  height: 54,
                  minWidth: 343,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(100)),
                ),
              ),
              InkWell(
                onTap: () {
                  Get.to(
                    () => Login(),
                    transition: Transition.leftToRight,
                    duration: Duration(milliseconds: 2000),
                  );
                },
                child: Container(
                    alignment: Alignment.center,
                    margin: EdgeInsets.only(top: 20, left: 20, right: 20),
                    child: customText("Already have an account ? login here",
                        Color(violetBlue), 16)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
