import 'package:flutter/material.dart';
import 'package:notify/common/colors.dart';
import 'package:notify/common/customText.dart';

class Register extends StatefulWidget {
  const Register({super.key});

  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Icon(Icons.arrow_back_ios,color: Color(violetBlue),size: 18,),
            customText("Back to login", Color(violetBlue), 16),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(20),
          child :Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              customText("Register", Colors.black, 32, customFontWeight: FontWeight.bold ),
              customText("and start taking notes", Colors.black, 16),
              Container(
                margin: EdgeInsets.only(top: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    customText("Full name", Colors.black, 16 ,customFontWeight: FontWeight.bold),
                    TextField(
                      keyboardType: TextInputType.text,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        // label: customText("Email", Colors.black, 16),
                        hintText: 'Example: jhon doe',
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    customText("Email Address", Colors.black, 16 ,customFontWeight: FontWeight.bold),
                    TextField(
                      keyboardType: TextInputType.emailAddress,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        // label: customText("Email", Colors.black, 16),
                        hintText: 'Example: abc@gmail.com',
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    customText("Password", Colors.black, 16 , customFontWeight: FontWeight.bold),
                    TextField(
                      keyboardType: TextInputType.visiblePassword,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        // label: customText("Email", Colors.black, 16),
                        hintText: '********',
                      ),
                    )
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    customText("Re-type password", Colors.black, 16 , customFontWeight: FontWeight.bold),
                    TextField(
                      keyboardType: TextInputType.visiblePassword,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        // label: customText("Email", Colors.black, 16),
                        hintText: '********',
                      ),
                    )
                  ],
                ),
              ),
              Container(
                alignment: Alignment.center,
                margin: EdgeInsets.only(top : 30),
                child: MaterialButton(
                  child: customText("Register" , Colors.white , 16 , customFontWeight: FontWeight.w500) ,
                  onPressed: (){
                  },
                  color: Color(violetBlue) ,
                  height: 54,
                  minWidth: 343,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)),
                ),
              ),
              Container(
                alignment: Alignment.center,
                margin: EdgeInsets.only(top : 20 , left:  20 , right: 20),
                  child: customText("Already have an account ? login here", Color(violetBlue), 16)),
            ],
          ),
        ),
      ),
    );
  }
}
