import 'package:flutter/material.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              margin: EdgeInsets.only(top: 20 ,),
              height: MediaQuery.of(context).size.height * 0.40,
              width: MediaQuery.of(context).size.width  * 0.70,
              child: Image.asset("images/flutter_logo.png"),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Color.fromRGBO(50, 50, 93, 0.25),
                    offset: Offset(0, 50), // Horizontal and vertical offset
                    blurRadius: 100, // Blur radius
                    spreadRadius: -20, // Negative spread radius
                  ),
                  BoxShadow(
                    color: Color.fromRGBO(0, 0, 0, 0.3),
                    offset: Offset(0, 30), // Horizontal and vertical offset
                    blurRadius: 60, // Blur radius
                    spreadRadius: -30, // Negative spread radius
                  ),
                ],
              ),
            ) ,
            SizedBox(
              height: 40,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Container(
                      height: 150,
                      width: 200,
                      padding: EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Color.fromRGBO(50, 50, 93, 0.25),
                            offset: Offset(0, 50), // Horizontal and vertical offset
                            blurRadius: 100, // Blur radius
                            spreadRadius: -20, // Negative spread radius
                          ),
                          BoxShadow(
                            color: Color.fromRGBO(0, 0, 0, 0.3),
                            offset: Offset(0, 30), // Horizontal and vertical offset
                            blurRadius: 60, // Blur radius
                            spreadRadius: -30, // Negative spread radius
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(20), // Match the Container's border radius
                        child: Image.asset(
                          "/images/splah1.jpg",
                          fit: BoxFit.cover, // Ensures the image covers the entire area
                        ),
                      ),
                    ),
                    SizedBox(height: 10,),
                    Container(
                      height: 50,
                      width: 150,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          color: Color(0xFFFF7F00) ,
                          borderRadius: BorderRadius.circular(10)
                      ),
                      child: Text("Login" , style: TextStyle(
                        color: Colors.white ,
                        fontSize: 20,
                      ),),
                    )
                  ],
                ),
                SizedBox(
                  width: 50,
                ),
                Column(
                  children: [
                    Container(
                      height: 150,
                      width: 200,
                      padding: EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Color.fromRGBO(50, 50, 93, 0.25),
                            offset: Offset(0, 50), // Horizontal and vertical offset
                            blurRadius: 100, // Blur radius
                            spreadRadius: -20, // Negative spread radius
                          ),
                          BoxShadow(
                            color: Color.fromRGBO(0, 0, 0, 0.3),
                            offset: Offset(0, 30), // Horizontal and vertical offset
                            blurRadius: 60, // Blur radius
                            spreadRadius: -30, // Negative spread radius
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(20), // Match the Container's border radius
                        child: Image.asset(
                          "/images/splah2.jpg",
                          fit: BoxFit.cover, // Ensures the image covers the entire area
                        ),
                      ),
                    ),
                    SizedBox(height: 10,),
                    Container(
                      height: 50,
                      width: 150,
                      decoration: BoxDecoration(
                          color: Color(0xFFFF7F00) ,
                          borderRadius: BorderRadius.circular(10)
                      ),
                      alignment: Alignment.center,
                      child: Text("Register" , style: TextStyle(
                        color: Colors.white ,
                        fontSize: 20,
                      ),),
                    )
                  ],
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
