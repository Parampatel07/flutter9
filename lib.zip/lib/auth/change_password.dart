import 'package:flutter/material.dart';
import 'package:notify/auth/forgot_password.dart';
import 'package:notify/auth/login.dart';
import 'package:notify/common/customeAppbar.dart';
import 'package:get/get.dart';
import '../common/colors.dart';
import '../common/customText.dart';

class ChangePassword extends StatefulWidget {
  const ChangePassword({super.key});

  @override
  State<ChangePassword> createState() => _ChangePasswordState();
}

class _ChangePasswordState extends State<ChangePassword> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customeAppBar("Change Password", "Back"),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: EdgeInsets.only(top: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      customText("Current password", Colors.black, 16 , customFontWeight: FontWeight.bold),
                      TextField(
                        keyboardType: TextInputType.visiblePassword,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          // label: customText("Email", Colors.black, 16),
                          hintText: '********',
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      customText("New password", Colors.black, 16 , customFontWeight: FontWeight.bold),
                      TextField(
                        keyboardType: TextInputType.visiblePassword,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          // label: customText("Email", Colors.black, 16),
                          hintText: '********',
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      customText("Confirm password", Colors.black, 16 , customFontWeight: FontWeight.bold),
                      TextField(
                        keyboardType: TextInputType.visiblePassword,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          // label: customText("Email", Colors.black, 16),
                          hintText: '********',
                        ),
                      )
                    ],
                  ),
                ),
                InkWell(
                  onTap: (){
                    Get.to(() => ForgotPassword(),transition: Transition.leftToRight ,duration : Duration(milliseconds: 2000),);
                  },
                  child: Container(
                      margin: EdgeInsets.only(top : 10),
                      child: customText("Forgot Password", Color(violetBlue), 16  ,customDecoration : TextDecoration.underline)),
                ),
                Container(
                  alignment: Alignment.center,
                  margin: EdgeInsets.only(top : 30),
                  child: MaterialButton(
                    child: customText("Save Changes" , Colors.white , 16 , customFontWeight: FontWeight.w500) ,
                    onPressed: (){
                      Get.to(() => Login(),transition: Transition.leftToRight ,duration : Duration(milliseconds: 2000),);
                    },
                    color: Color(violetBlue) ,
                    height: 54,
                    minWidth: 343,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
