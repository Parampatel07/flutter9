import 'package:flutter/material.dart';

import '../common/colors.dart';
import '../common/customText.dart';

class ChangePassword extends StatefulWidget {
  const ChangePassword({super.key});

  @override
  State<ChangePassword> createState() => _ChangePasswordState();
}

class _ChangePasswordState extends State<ChangePassword> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: customText("Change Password ", Colors.black, 16),
        leadingWidth : 75 ,
        leading: Row(
          children: [
            SizedBox(
              width: 20,
            ),
            Icon(Icons.arrow_back_ios,color: Color(violetBlue),size: 12,),
            customText("Back ", Color(violetBlue), 16),
          ],
        ),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: EdgeInsets.only(top: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      customText("Current password", Colors.black, 16 , customFontWeight: FontWeight.bold),
                      TextField(
                        keyboardType: TextInputType.visiblePassword,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          // label: customText("Email", Colors.black, 16),
                          hintText: '********',
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      customText("New password", Colors.black, 16 , customFontWeight: FontWeight.bold),
                      TextField(
                        keyboardType: TextInputType.visiblePassword,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          // label: customText("Email", Colors.black, 16),
                          hintText: '********',
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      customText("Confirm password", Colors.black, 16 , customFontWeight: FontWeight.bold),
                      TextField(
                        keyboardType: TextInputType.visiblePassword,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          // label: customText("Email", Colors.black, 16),
                          hintText: '********',
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                    margin: EdgeInsets.only(top : 10),
                    child: customText("Forgot Password", Color(violetBlue), 16  ,customDecoration : TextDecoration.underline)),
                Container(
                  alignment: Alignment.center,
                  margin: EdgeInsets.only(top : 30),
                  child: MaterialButton(
                    child: customText("Save Changes" , Colors.white , 16 , customFontWeight: FontWeight.w500) ,
                    onPressed: (){
                    },
                    color: Color(violetBlue) ,
                    height: 54,
                    minWidth: 343,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
