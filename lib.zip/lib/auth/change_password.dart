import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get_storage/get_storage.dart';
import 'package:notify/auth/forgot_password.dart';
import 'package:notify/auth/login.dart';
import 'package:notify/common/customeAppbar.dart';
import 'package:get/get.dart';
import '../common/colors.dart';
import '../common/customText.dart';
import '../database/sqflite_helper.dart';

class ChangePassword extends StatefulWidget {
  const ChangePassword({super.key});

  @override
  State<ChangePassword> createState() => _ChangePasswordState();
}

class _ChangePasswordState extends State<ChangePassword> {
  final currentPasswordController = TextEditingController();
  final newPasswordController = TextEditingController();
  final confirmPasswordController = TextEditingController();
  dynamic currentPasswordVisible = true;
  dynamic confirmPassowrdVisible = true;
  dynamic newPasswordVisible = true;
  GetStorage localStorage = GetStorage();

  @override
  void initState() {
    currentPasswordController
        .addListener(() => {handleCurrentPasswordChange()});

    newPasswordController.addListener(() => {handleNewPasswordChange()});

    confirmPasswordController
        .addListener(() => {handleConfirmPasswordChange()});
    super.initState();
  }

  void dispose() {
    currentPasswordController.dispose();
    newPasswordController.dispose();
    confirmPasswordController.dispose();
    super.dispose();
  }

  dynamic handleCurrentPasswordChange() {
    print("current password : " + currentPasswordController.text.toString());
  }

  dynamic handleNewPasswordChange() {
    print("new password : " + newPasswordController.text.toString());
  }

  dynamic handleConfirmPasswordChange() {
    print("confirm password : " + confirmPasswordController.text.toString());
  }

  dynamic handleCurrentPasswordVisibleChange() {
    setState(() {
      currentPasswordVisible = !currentPasswordVisible;
    });
  }

  dynamic handleNewPasswordVisibleChange() {
    setState(() {
      newPasswordVisible = !newPasswordVisible;
    });
  }

  dynamic handleConfirmPasswordVisibleChange() {
    setState(() {
      confirmPassowrdVisible = !confirmPassowrdVisible;
    });
  }

  dynamic handleChangePasswordClick() {
    String oldPassword = currentPasswordController.text.toString().trim();
    String newPassword = newPasswordController.text.toString().trim();
    String confirmPassword = confirmPasswordController.text.toString().trim();
    if (oldPassword == "" || newPassword == "" || confirmPassword == "") {
      Fluttertoast.showToast(
          msg: "Please fill all the inputs ",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0,
          timeInSecForIosWeb: 5,
          webBgColor:
          "linear-gradient(342deg, rgba(196,12,12,1) 52%, rgba(196,12,12,1) 100%)",
          webPosition: "center");
    }else if(newPassword != confirmPassword){
      Fluttertoast.showToast(
          msg: "New password and confirm password must be same ",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0,
          timeInSecForIosWeb: 5,
          webBgColor:
          "linear-gradient(342deg, rgba(196,12,12,1) 52%, rgba(196,12,12,1) 100%)",
          webPosition: "center");
    }
    else {
      print("localStorage.read('_id') " + localStorage.read('_id').toString());
      var id = localStorage.read('_id').toString() ;
      var query = "UPDATE user set password = '${newPassword}' where _id = ${id}";
      userChangePassword(query);

      Get.to(
        () => Login(),
        transition: Transition.leftToRight,
        duration: Duration(milliseconds: 2000),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customeAppBar("Change Password", "Back"),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: EdgeInsets.only(top: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      customText("Current password", Colors.black, 16,
                          customFontWeight: FontWeight.bold),
                      TextField(
                        controller: currentPasswordController,
                        obscureText: currentPasswordVisible,
                        keyboardType: TextInputType.visiblePassword,
                        decoration: InputDecoration(
                          suffixIcon: InkWell(
                            onTap: () {
                              handleCurrentPasswordVisibleChange();
                            },
                            child: currentPasswordVisible == true
                                ? Icon(Icons.remove_red_eye_outlined)
                                : Icon(Icons.remove_red_eye_rounded),
                          ),
                          border: OutlineInputBorder(),
                          // label: customText("Email", Colors.black, 16),
                          hintText: '********',
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      customText("New password", Colors.black, 16,
                          customFontWeight: FontWeight.bold),
                      TextField(
                        controller: newPasswordController,
                        keyboardType: TextInputType.visiblePassword,
                        obscureText: newPasswordVisible,
                        decoration: InputDecoration(
                          suffixIcon: InkWell(
                            onTap: () {
                              handleNewPasswordVisibleChange();
                            },
                            child: newPasswordVisible == true
                                ? Icon(Icons.remove_red_eye_outlined)
                                : Icon(Icons.remove_red_eye_rounded),
                          ),
                          border: OutlineInputBorder(),
                          // label: customText("Email", Colors.black, 16),
                          hintText: '********',
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      customText("Confirm password", Colors.black, 16,
                          customFontWeight: FontWeight.bold),
                      TextField(
                        controller: confirmPasswordController,
                        keyboardType: TextInputType.visiblePassword,
                        obscureText: confirmPassowrdVisible,
                        decoration: InputDecoration(
                          suffixIcon: InkWell(
                            onTap: () {
                              handleConfirmPasswordVisibleChange();
                            },
                            child: confirmPassowrdVisible == true
                                ? Icon(Icons.remove_red_eye_outlined)
                                : Icon(Icons.remove_red_eye_rounded),
                          ),
                          border: OutlineInputBorder(),
                          // label: customText("Email", Colors.black, 16),
                          hintText: '********',
                        ),
                      )
                    ],
                  ),
                ),
                InkWell(
                  onTap: () {
                    Get.to(
                      () => ForgotPassword(),
                      transition: Transition.leftToRight,
                      duration: Duration(milliseconds: 2000),
                    );
                  },
                  child: Container(
                      margin: EdgeInsets.only(top: 10),
                      child: customText(
                          "Forgot Password", Color(violetBlue), 16,
                          customDecoration: TextDecoration.underline)),
                ),
                Container(
                  alignment: Alignment.center,
                  margin: EdgeInsets.only(top: 30),
                  child: MaterialButton(
                    child: customText("Save Changes", Colors.white, 16,
                        customFontWeight: FontWeight.w500),
                    onPressed: () {
                      handleChangePasswordClick();
                    },
                    color: Color(violetBlue),
                    height: 54,
                    minWidth: 343,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(100)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
