import 'package:flutter/material.dart';
import 'package:flutter9_shop/common/AppBar.dart';
import 'package:flutter9_shop/common/Drawer.dart';
import 'package:flutter9_shop/common/textStyle.dart';

class WishlistScreen extends StatefulWidget {
  const WishlistScreen({super.key});

  @override
  State<WishlistScreen> createState() => _WishlistScreenState();
}

class _WishlistScreenState extends State<WishlistScreen> {
  int selectedPageValue = 5;
  int CartQuantity = 10;
  int CartAmount = 1200 ;
  dynamic handlePlusButtonClick() {
    setState(() {
      CartQuantity = CartQuantity + 1;
    });
  }

  dynamic handleMinusButtonClick() {
    if (CartQuantity >= 1) {
      setState(() {
        CartQuantity = CartQuantity - 1;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar(),
      drawer: customDrawer(selectedPageValue),
      body: Container(
        alignment: Alignment.topLeft,
        margin: EdgeInsets.all(20),
        height: MediaQuery.of(context).size.height * 0.90,
        width: MediaQuery.of(context).size.width,
        // color: Colors.red,
        child: ListView.builder(itemBuilder: (context,index){
          return Container(
            margin: EdgeInsets.all(7),
            padding: EdgeInsets.all(10),
            height: 120,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: Colors.orange,
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  height: 100,
                  width: 100,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      image: DecorationImage(
                          fit: BoxFit.contain,
                          image: NetworkImage(
                              "https://i5.walmartimages.com/seo/HP-14-Laptop-Intel-Core-i3-1115G4-4GB-RAM-128G-SSD-Natural-Silver-Windows-11-Home-in-S-mode-14-dq2031wm_d3df6009-cc66-44f8-b45e-16b8cb670e8c.22c4512667d72a24e1a97ba67bd5fc0d.jpeg"))),
                ),
                SizedBox(
                  width: 20,
                ),
                Container(
                  child: Column(
                    children: [
                      SizedBox(
                        width: 300,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                customText("Product - 1"),
                                customText("Size : 15 Inch"),
                                Row(
                                  children: [
                                    InkWell(
                                      onTap: () {
                                        handleMinusButtonClick();
                                      },
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius:
                                          BorderRadius.circular(10),
                                        ),
                                        padding: EdgeInsets.symmetric( vertical: 5,
                                            horizontal: 15),
                                        child: Icon(Icons.delete),
                                      ),
                                    ),
                                    SizedBox(
                                      width: 7,
                                    ),
                                    InkWell(
                                      onTap: () {
                                        handleMinusButtonClick();
                                      },
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius:
                                          BorderRadius.circular(10),
                                        ),
                                        padding: EdgeInsets.symmetric( vertical: 7,
                                            horizontal: 15),
                                        child: Text("Add to cart"),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            customText("₹1200"),
                          ],
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
          );
        },
          itemCount: 5,
        )
        ,),
    );
  }
}
