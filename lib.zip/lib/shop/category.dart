import 'package:flutter/material.dart';
import 'package:flutter9_shop/common/textStyle.dart';

import '../common/AppBar.dart';
import '../common/Drawer.dart';

class CategoryScreen extends StatefulWidget {
  const CategoryScreen({super.key});

  @override
  State<CategoryScreen> createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {
  final selectedPageValue = 2;
  final CategoryList = [
    {
      "title": "Category - 1",
      "image": "https://i5.walmartimages.com/seo/HP-14-Laptop-Intel-Core-i3-1115G4-4GB-RAM-128G-SSD-Natural-Silver-Windows-11-Home-in-S-mode-14-dq2031wm_d3df6009-cc66-44f8-b45e-16b8cb670e8c.22c4512667d72a24e1a97ba67bd5fc0d.jpeg"
    },
    {
      "title": "Category - 2",
      "image": "https://www.asus.com/media/Odin/Websites/global/ProductLine/20200824120814.jpg"
    },
    {
      "title": "Category - 4",
      "image": "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/iphone-13-pro-family-hero?wid=940&hei=1112&fmt=png-alpha&.v=1645552346270"
    },
    {
      "title": "Category - 5",
      "image": "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/iphone-13-pro-family-hero?wid=940&hei=1112&fmt=png-alpha&.v=1645552346270"
    },
    {
      "title": "Category - 6",
      "image": "https://m.media-amazon.com/images/I/71vvXGmdKWL._SL1500_.jpg"
    },
    {
      "title": "Category - 7",
      "image": "https://m.media-amazon.com/images/I/71vvXGmdKWL._SL1500_.jpg"
    },
    {
      "title": "Category - 8",
      "image": "https://m.media-amazon.com/images/I/71vvXGmdKWL._SL1500_.jpg"
    },
    {
      "title": "Category - 9",
      "image": "https://m.media-amazon.com/images/I/71vvXGmdKWL._SL1500_.jpg"
    },
    {
      "title": "Category - 10",
      "image": "https://m.media-amazon.com/images/I/71vvXGmdKWL._SL1500_.jpg"
    }
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar(),
      drawer: customDrawer(selectedPageValue),
      body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: GridView.builder(
            itemCount: CategoryList.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio : 1.5/1
              ),
              itemBuilder: (BuildContext context, index) {
                return Container(
                  alignment: Alignment.bottomCenter,
                  padding: EdgeInsets.only(bottom: 20),
                  child: customText(CategoryList[index]['title'].toString(), color: Colors.white),
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: NetworkImage(CategoryList[index]['image'].toString(),
                      ),
                      fit: BoxFit.contain,
                      colorFilter: ColorFilter.mode(
                          Colors.black.withOpacity(0.4), BlendMode.darken),
                    ),
                  ),
                );
              }),),
    );
  }
}
