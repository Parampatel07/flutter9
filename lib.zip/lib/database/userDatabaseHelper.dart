import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi_web/sqflite_ffi_web.dart';

Future<bool> checkUserExits(String email) async {
  databaseFactory = databaseFactoryFfiWeb;
  String ApplicationPath = "C:/flutter9/notify/flutter9_notes/assets/database/";
  String DatabasePathAndName = ApplicationPath + "notes4.db";
  Database database = await openDatabase(DatabasePathAndName, version: 2,
      onCreate: (Database db, int version) async {
    await db.execute(
        "CREATE TABLE IF NOT EXISTS 'user' ( '_id' INTEGER PRIMARY KEY,  'name' VARCHAR(255) NOT NULL,  'email' VARCHAR(255) NOT NULL , 'password' VARCHAR(255) NOT NULL )");
  });
  int id1 = 0;
  List<Map> list =
      await database.rawQuery("Select email from user where email = '${email.toString()}'");
  print("Check user list ");
  print(list);
  if (list.length >= 1) {
    return false;
  } else {
    return true;
  }
}

Future<bool> checkUserLogin(String email,String password) async {
  databaseFactory = databaseFactoryFfiWeb;
  String ApplicationPath = "C:/flutter9/notify/flutter9_notes/assets/database/";
  String DatabasePathAndName = ApplicationPath + "notes4.db";
  Database database = await openDatabase(DatabasePathAndName, version: 2,
      onCreate: (Database db, int version) async {
    await db.execute(
        "CREATE TABLE IF NOT EXISTS 'user' ( '_id' INTEGER PRIMARY KEY,  'name' VARCHAR(255) NOT NULL,  'email' VARCHAR(255) NOT NULL , 'password' VARCHAR(255) NOT NULL )");
  });
  List<Map> list =
      await database.rawQuery("SELECT * from user where email = '${email.toString()}' and password = '${password.toString()}'");
  print("Check user list ");
  print(list);
  if (list.length >= 1) {
    return true;
  } else {
    return false;
  }
}
