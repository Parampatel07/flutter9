import 'dart:io';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite_common_ffi_web/sqflite_ffi_web.dart';
class DatabaseHelper
{
  static DatabaseHelper? _databaseHelper;
  static Database? _database;
  DatabaseHelper._createInstance(); //named constructor
  factory DatabaseHelper()
  {
    print("DatabaseHelper() class factory method is called...");
    if(_databaseHelper == null)
      _databaseHelper =  DatabaseHelper._createInstance();
    return _databaseHelper!;
  }
  // Future<Database?> get database async
  // {
  //   print("getter method database is called...");
  //   if(_database == null)
  //     _database = await initilizeDatabase();
  //   return _database;
  // }
  Future<Database> initilizeDatabase() async {
    databaseFactory = databaseFactoryFfiWeb;
    // print("initilizeDatabase() method is called ...");
    String ApplicationPath = "C:/flutter9/notify/flutter9_notes/assets/database/";
    String DatabasePathAndName = ApplicationPath + "notes.db";
    // var db = openDatabase(DatabasePathAndName,version: 1,onCreate:CreateTables);
    // // var factory = databaseFactoryFfiWeb;
    // // var db = await factory.openDatabase('my_db.db');
    // // print("db is completed ");
    // return db;
    Database database = await openDatabase(DatabasePathAndName, version: 1,
        onCreate: (Database db, int version) async {
          // When creating the db, create the table
          await db.execute(
              "CREATE TABLE IF NOT EXISTS 'user' ( 'id' INT AUTO_INCREMENT PRIMARY KEY,  'name' VARCHAR(255) NOT NULL,  'email' VARCHAR(255) NOT NULL , 'password' VARCHAR(255) NOT NULL )");
        });
    return database;
  }
  Future<void> CreateTables(Database database, int version) async
  {
    var query = " CREATE TABLE IF NOT EXISTS 'user' ( 'id' INT AUTO_INCREMENT PRIMARY KEY,  'name' VARCHAR(255) NOT NULL,  'email' VARCHAR(255) NOT NULL , 'password' VARCHAR(255) NOT NULL )" ;
    print("CreateTables() method is called ...");
    await database.execute(query);
    print("tables created");
  }
  //insert, update, delete queries will be executed using runQuery
  // Future<void> runQuery(String sql) async {
  //   print(sql);
  //   Database? db = this.database as Database?;
  //   await db?.execute(sql);
  //   print("Query Executed Successfully");
  // }
  //select query
  // Future<dynamic> fetchRow(String sql) async {
  //   Database? db = this.database as Database?;
  //   var result  =  await db?.rawQuery(sql);
  //   print(result);
  //   return result;
  // }
}