import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi_web/sqflite_ffi_web.dart';

Future<void> insertValueUser(String query) async {
  databaseFactory = databaseFactoryFfiWeb;
  String ApplicationPath = "C:/flutter9/notify/flutter9_notes/assets/database/";
  String DatabasePathAndName = ApplicationPath + "notes4.db";
  Database database = await openDatabase(DatabasePathAndName, version: 2,
      onCreate: (Database db, int version) async {
        await db.execute(
           "CREATE TABLE IF NOT EXISTS 'user' ( '_id' INTEGER PRIMARY KEY,  'name' VARCHAR(255) NOT NULL,  'email' VARCHAR(255) NOT NULL , 'password' VARCHAR(255) NOT NULL )");
  });
  int id1 = 0;
  await database.transaction((txn) async {
    id1 = await txn.rawInsert(query);
    print('inserted1: $id1');
  });
  List<Map> list = await database.rawQuery('SELECT * FROM user where _id = ' + id1.toString());
  print("user list ");
  print(list);
}