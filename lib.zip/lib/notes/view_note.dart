import 'package:flutter/material.dart';
import 'package:notify/common/colors.dart';
import 'package:notify/common/customText.dart';
import 'package:notify/common/customeAppbar.dart';

class ViewNote extends StatefulWidget {
  const ViewNote({super.key});

  @override
  State<ViewNote> createState() => _ViewNoteState();
}

class _ViewNoteState extends State<ViewNote> {
  var CardList = [
    violetCard,
    redCard,
    greenCard,
    yellowCard,
  ];
  var CardImage = [
    "images/normal_note.png",
    "images/important_note.png",
    "images/private_note.png",
    "images/causal_note.png",
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomSheet: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Color(violetBlue),
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.white.withOpacity(.60),
        selectedFontSize: 14,
        unselectedFontSize: 14,
        onTap: (value) {
          // Respond to item press.
        },
        items: [
          BottomNavigationBarItem(
            label: 'Important',
            icon: Icon(Icons.notification_important_rounded),
          ),
          BottomNavigationBarItem(
            label: 'Casual',
            icon: Icon(Icons.note_alt),
          ),
          BottomNavigationBarItem(
            label: 'Private',
            icon: Icon(Icons.lock),
          ),
          BottomNavigationBarItem(
            label: 'Normal',
            icon: Icon(Icons.width_normal_rounded),
          ),
        ],
      ),
      appBar: customeAppBar(
        "View Note",
        "",
        leadingIcon: Icons.account_box_rounded,
        leadingIconSize: 30,
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: double.infinity,
        padding: EdgeInsets.all(20),
        child: ListView.builder(
          itemBuilder: (context, index) {
            return Container(
              margin: EdgeInsets.only(top: 15),
              height: 80,
              width: double.infinity,
              decoration: BoxDecoration(
                  color: Color(CardList[index]),
                  borderRadius: BorderRadius.circular(8)),
              child: Container(
                child: Row(
                  children: [
                    Image.asset(
                      CardImage[index].toString(),
                      height: 200,
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        customText("Heading", Colors.white, 16),
                        customText("Description goes here", Colors.white, 12),
                      ],
                    )
                  ],
                ),
              ),
            );
          },
          itemCount: 4,
        ),
      ),
    );
  }
}
