import 'package:flutter/material.dart';
import 'package:notify/common/colors.dart';
import 'package:notify/common/customText.dart';
import 'package:notify/common/customeAppbar.dart';
import 'package:wolt_modal_sheet/wolt_modal_sheet.dart';

class ViewNote extends StatefulWidget {
  const ViewNote({super.key});

  @override
  State<ViewNote> createState() => _ViewNoteState();
}

class _ViewNoteState extends State<ViewNote> {
  var CardList = [
    violetCard,
    redCard,
    greenCard,
    yellowCard,
  ];
  var CardImage = [
    "images/normal_note.png",
    "images/important_note.png",
    "images/private_note.png",
    "images/causal_note.png",
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showCenteredWoltModal(context);
        },
        backgroundColor: const Color(0xFF483D8B), // Replace violetBlue
        child: const Icon(Icons.add, color: Colors.white),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(50),
        ),
      ),
      bottomSheet: BottomAppBar(
        notchMargin : 10,
        shape:  CircularNotchedRectangle(),
        color: Color(violetBlue), // Replace violetBlue with its hex color value
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            IconButton(
              icon: Icon(Icons.notification_important_rounded,
                  color: Colors.white),
              onPressed: () {
                // Handle Important tap
              },
            ),
            IconButton(
              icon: Icon(Icons.note_alt, color: Colors.white),
              onPressed: () {
                // Handle Casual tap
              },
            ),
            IconButton(
              icon: Icon(Icons.lock, color: Colors.white),
              onPressed: () {
                // Handle Private tap
              },
            ),
            IconButton(
              icon: Icon(Icons.width_normal_rounded, color: Colors.white),
              onPressed: () {
                // Handle Normal tap
              },
            ),
          ],
        ),
      ),
      appBar: customeAppBar(
        "View Note",
        "",
        leadingIcon: Icons.account_box_rounded,
        leadingIconSize: 30,
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: double.infinity,
        padding: EdgeInsets.all(20),
        child: ListView.builder(
          itemBuilder: (context, index) {
            return Container(
              margin: EdgeInsets.only(top: 15),
              height: 80,
              width: double.infinity,
              decoration: BoxDecoration(
                  color: Color(CardList[index]),
                  borderRadius: BorderRadius.circular(8)),
              child: Container(
                child: Row(
                  children: [
                    Image.asset(
                      CardImage[index].toString(),
                      height: 200,
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        customText("Heading", Colors.white, 16),
                        customText("Description goes here", Colors.white, 12),
                      ],
                    )
                  ],
                ),
              ),
            );
          },
          itemCount: 4,
        ),
      ),
    );
  }
}

void _showCenteredWoltModal(BuildContext context) {
  showDialog(
    context: context,
    barrierDismissible: true,
    builder: (BuildContext dialogContext) {
      return Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        insetPadding: const EdgeInsets.all(16),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Title
              Text(
                'Alert',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              // Description
              Text(
                'Are you sure you want to proceed with this action?',
                style: TextStyle(fontSize: 16, color: Colors.black54),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              // Action Buttons
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey[200],
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 24, vertical: 12),
                    ),
                    onPressed: () {
                      Navigator.of(dialogContext).pop();
                    },
                    child: const Text('Cancel'),
                  ),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF483D8B), // violetBlue
                      padding: const EdgeInsets.symmetric(
                          horizontal: 24, vertical: 12),
                    ),
                    onPressed: () {
                      // Perform your action
                      Navigator.of(dialogContext).pop();
                    },
                    child: const Text('Confirm',style: TextStyle(
                      color: Colors.white,
                    ),),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    },
  );
}
