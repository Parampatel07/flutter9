import 'package:flutter/material.dart';
import 'package:notify/common/colors.dart';
import 'package:notify/common/customText.dart';
import 'package:notify/common/customeAppbar.dart';
import 'package:wolt_modal_sheet/wolt_modal_sheet.dart';
import 'package:notify/common/woltModal.dart';
class ViewNote extends StatefulWidget {
  const ViewNote({super.key});

  @override
  State<ViewNote> createState() => _ViewNoteState();
}

class _ViewNoteState extends State<ViewNote> {
  var CardList = [
    violetCard,
    redCard,
    greenCard,
    yellowCard,
  ];
  var CardImage = [
    "images/normal_note.png",
    "images/important_note.png",
    "images/private_note.png",
    "images/causal_note.png",
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showCenteredWoltModal(context);
        },
        backgroundColor: const Color(0xFF483D8B), // Replace violetBlue
        child: const Icon(Icons.add, color: Colors.white),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(50),
        ),
      ),
      bottomSheet: BottomAppBar(
        notchMargin : 10,
        shape:  CircularNotchedRectangle(),
        color: Color(violetBlue), // Replace violetBlue with its hex color value
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            IconButton(
              icon: Icon(Icons.notification_important_rounded,
                  color: Colors.white),
              onPressed: () {
                // Handle Important tap
              },
            ),
            IconButton(
              icon: Icon(Icons.note_alt, color: Colors.white),
              onPressed: () {
                // Handle Casual tap
              },
            ),
            IconButton(
              icon: Icon(Icons.lock, color: Colors.white),
              onPressed: () {
                // Handle Private tap
              },
            ),
            IconButton(
              icon: Icon(Icons.width_normal_rounded, color: Colors.white),
              onPressed: () {
                // Handle Normal tap
              },
            ),
          ],
        ),
      ),
      appBar: customeAppBar(
        "View Note",
        "",
        leadingIcon: Icons.account_box_rounded,
        leadingIconSize: 30.01,
        screen : 'view_notes'
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: double.infinity,
        padding: EdgeInsets.all(20),
        child: ListView.builder(
          itemBuilder: (context, index) {
            return Container(
              margin: EdgeInsets.only(top: 15),
              height: 80,
              width: double.infinity,
              decoration: BoxDecoration(
                  color: Color(CardList[index]),
                  borderRadius: BorderRadius.circular(8)),
              child: Container(

                child: Row(
                  children: [
                    Image.asset(
                      CardImage[index].toString(),
                      height: 200,
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        customText("Heading", Colors.white, 16),
                        customText("Description goes here", Colors.white, 12),
                      ],
                    )
                  ],
                ),
              ),
            );
          },
          itemCount: 4,
        ),
      ),
    );
  }
}

