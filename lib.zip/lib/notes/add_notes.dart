import 'package:flutter/material.dart';

import '../common/colors.dart';
import '../common/customText.dart';
import '../common/customeAppbar.dart';
import '../common/dashboardCards.dart';

class AddNotes extends StatelessWidget {
  const AddNotes({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customeAppBar("New Notes", "Home"),
      body: Container(
        height: MediaQuery.of(context).size.height ,
        width: double.infinity,
        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              customText("What do you want to note", Colors.black, 32,
                  customFontWeight: FontWeight.bold),
              Container(
                margin: EdgeInsets.only(top: 22),
                child: Row(
                  children: [
                    DashboardCard("Normal ", "Use free text area, feel free to write it all" , Color(violetCard) , "images/normal_note.png" ),
                    SizedBox( width:  16,),
                    DashboardCard("Casual", "Near/future goals, notes and keep focus  all" , Color(yellowCard) , "images/causal_note.png" ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 16),
                child: Row(
                  children: [
                    DashboardCard("Important ", "Use free text area, feel free to write it all" , Color(redCard) , "images/important_note.png" ),
                    SizedBox( width:  16,),
                    DashboardCard("Private ", "Near/future goals, notes and keep focus  all" , Color(greenCard) , "images/private_note.png" ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
