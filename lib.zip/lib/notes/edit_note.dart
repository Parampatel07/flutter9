import 'package:flutter/material.dart';
import 'package:notify/common/customeAppbar.dart';
import 'package:get/get.dart';
import 'package:notify/notes/view_note.dart';
import '../common/colors.dart';
import '../common/customText.dart';
class EditNotes extends StatefulWidget {
  const EditNotes({super.key});

  @override
  State<EditNotes> createState() => _EditNotesState();
}

class _EditNotesState extends State<EditNotes> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customeAppBar("Edit note", "Back"),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.only(top: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  customText("Enter title", Colors.black, 16 ,customFontWeight: FontWeight.bold),
                  TextField(
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      // label: customText("Email", Colors.black, 16),
                      hintText: 'Example: This is first note',
                    ),
                  )
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  customText("Enter detail", Colors.black, 16 ,customFontWeight: FontWeight.bold),
                  TextField(
                    maxLines: 5,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      // label: customText("Email", Colors.black, 16),
                      hintText: 'Example: creating my first note',
                    ),
                  )
                ],
              ),
            ),
            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.only(top : 30),
              child: MaterialButton(
                child: customText("Update " , Colors.white , 16 , customFontWeight: FontWeight.w500) ,
                onPressed: (){
                  Get.to(
                        () => ViewNote(),
                    transition: Transition.leftToRight,
                    duration: Duration(milliseconds: 2000),
                  );
                },
                color: Color(violetBlue) ,
                height: 54,
                minWidth: 343,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
