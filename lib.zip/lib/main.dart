import 'package:flutter/material.dart';
import 'auth/change_password.dart';
import 'auth/forgot_password.dart';
import 'auth/login.dart';
import 'auth/register.dart';
import 'auth/splash.dart';
import 'notes/add_notes.dart';
import 'notes/create_note.dart';
import 'notes/edit_note.dart';
import 'notes/view_note.dart';

void main() {
  runApp(const MaterialApp(
    home: ViewNote(),
  ));
}
