import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi_web/sqflite_ffi_web.dart';
import 'auth/change_password.dart';
import 'auth/edit_user.dart';
import 'auth/forgot_password.dart';
import 'auth/login.dart';
import 'auth/register.dart';
import 'auth/splash.dart';
import 'notes/add_notes.dart';
import 'notes/create_note.dart';
import 'notes/edit_note.dart';
import 'notes/view_note.dart';
import 'package:get/get.dart';


void main() {
  runApp(const GetMaterialApp(
    debugShowCheckedModeBanner: false,
    home: SplashScreen(),
  ));
}
