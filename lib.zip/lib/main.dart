import 'package:flutter/material.dart';
import 'package:flutter9_shop/auth/forgotPassword.dart';
import 'package:flutter9_shop/shop/cart.dart';
import 'package:flutter9_shop/shop/category.dart';
import 'package:flutter9_shop/shop/products.dart';
import 'package:flutter9_shop/shop/singleProduct.dart';
import 'package:flutter9_shop/shop/whishlist.dart';

import 'auth/changePassword.dart';
import 'auth/editUser.dart';
import 'auth/login.dart';
import 'auth/register.dart';
import 'auth/splash.dart';

void main() {
  runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      home:  WishlistScreen()));
}
