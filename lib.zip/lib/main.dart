import 'package:flutter/material.dart';
import 'auth/change_password.dart';
import 'auth/forgot_password.dart';
import 'auth/login.dart';
import 'auth/register.dart';
import 'auth/splash.dart';

void main() {
  runApp(const MaterialApp(
    home: ForgotPassword(),
  ));
}
